﻿using System.ComponentModel.DataAnnotations;

namespace appPetShop.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "O username é obrigatório.")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "A senha é obrigatória.")]
        [DataType(DataType.Password)]
        public string Senha { get; set; } = string.Empty;
    }
}
